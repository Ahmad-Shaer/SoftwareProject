import 'dart:async';
import 'dart:math';

import 'package:arwamar/screen/login.dart';
import 'package:flutter/material.dart';
//import 'package:arwamar/screen/splash_screen.dart';
//import 'package:flutter/material.dart';

class splash_screen extends StatefulWidget {
  static const String screenRoute = 'splash_screen';
  const splash_screen({super.key});

  @override
  State<splash_screen> createState() => _Splash_ScreenState();
}

class _Splash_ScreenState extends State<splash_screen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(
        Duration(seconds: 3),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => login())));
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 205, 77, 228),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 50,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image(image: AssetImage('assets/6.jpg')),
                    ))
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              'Travel_ Nest',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 25),
            )
          ],
        ),
      ),
    );
  }
}
