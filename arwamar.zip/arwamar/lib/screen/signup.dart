import 'package:arwamar/screen/login.dart';
import 'package:flutter/material.dart';

class signup extends StatefulWidget {
  static const String screenRoute = 'signup';

  const signup({super.key});

  @override
  State<signup> createState() => _signupState();
}

class _signupState extends State<signup> {
  @override
  bool _obscureText = true;

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                color: Colors.purple,
                width: double.infinity,
                height: 120,
              ),
              Stack(
                alignment: Alignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 50,
                  ),
                  Text(
                    'Travel_ Nest',
                    style: TextStyle(
                        color: Colors.purple,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  ),
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                Row(
                  children: [
                    MaterialButton(
                      onPressed: () {
                        Navigator.pushNamed(context, login.screenRoute);
                      },
                      child: Text(
                        'SIGN IN/',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 20,
                        ),
                      ),
                    ),
                    MaterialButton(
                      onPressed: () {},
                      child: Text(
                        'SIGN UP',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  onChanged: (value) {},
                  decoration: InputDecoration(
                      fillColor: Color.fromARGB(117, 219, 218, 218),
                      filled: true,
                      hintText: 'User_Name',
                      prefixIcon:
                          Icon(Icons.drive_file_rename_outline_outlined),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(40)))),
                ),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  onChanged: (value) {},
                  decoration: InputDecoration(
                      fillColor: Color.fromARGB(117, 219, 218, 218),
                      filled: true,
                      hintText: 'Phone_Number',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(40)))),
                ),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  onChanged: (value) {},
                  decoration: InputDecoration(
                      fillColor: Color.fromARGB(117, 219, 218, 218),
                      filled: true,
                      hintText: 'E-mail',
                      prefixIcon: Icon(Icons.email),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(40)))),
                ),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  obscureText: _obscureText,
                  onChanged: (value) {},
                  decoration: InputDecoration(
                      fillColor: Color.fromARGB(117, 219, 218, 218),
                      filled: true,
                      hintText: 'Password',
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: GestureDetector(
                        onTap: () {
                          setState(() {
                            _obscureText = !_obscureText;
                          });
                        },
                        child: Icon(
                          _obscureText
                              ? Icons.visibility_off
                              : Icons.visibility,
                        ),
                      ),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(40)))),
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    MaterialButton(
                      onPressed: () {},
                      child: Text(
                        'Forget password',
                        style: TextStyle(
                          color: const Color.fromARGB(185, 0, 0, 0),
                          fontSize: 15,
                          //    fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                MaterialButton(
                  onPressed: () {},
                  minWidth: double.infinity,
                  height: 50,
                  color: Colors.purple,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(50))),
                  child: Text(
                    'SIGN IN',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )
              ],
            ),
          ),

// or continue with
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Row(
              children: [
                Expanded(
                  child: Divider(
                    thickness: 0.5,
                    color: Colors.grey[400],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: Text(
                    'Or continue with',
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                ),
                Expanded(
                  child: Divider(
                    thickness: 0.5,
                    color: Colors.grey[400],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          SingleChildScrollView(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/face.png',
                  width: 60,
                  height: 60,
                  alignment: Alignment.center,
                ), // Adjust the width and height as needed
                SizedBox(width: 25),
                Image.asset(
                  'assets/insta.png',
                  width: 300,
                  height: 110,
                  alignment: Alignment.center,
                ), // Adjust the width and height as needed
              ],
            ),
          )
        ],
      ),
    );
  }
}
