package com.example.arwamar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
